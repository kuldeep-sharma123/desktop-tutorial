import pytest
from playwright.sync_api import sync_playwright
from datetime import datetime


@pytest.fixture(scope="function")
def page():

    playwright = sync_playwright().start()

    browser = playwright.chromium.launch(
        headless=False
    )

    page = browser.new_page()

    page.goto(
        "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
    )

    yield page

    browser.close()
    playwright.stop()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):

    outcome = yield
    rep = outcome.get_result()

    if rep.when == "call" and rep.failed:

        page = item.funcargs.get("page")

        if page:

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

            page.screenshot(
                path=f"screenshots/{item.name}_{timestamp}.png",
                full_page=True
            )