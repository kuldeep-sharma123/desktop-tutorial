import pytest

from pages.login_page import LoginPage
from utils.csv_reader import read_csv


login_data = read_csv("data/login_data.csv")


@pytest.mark.parametrize(
    "data",
    login_data
)

def test_login(page, data):

    login = LoginPage(page)

    login.login(
        data["username"],
        data["password"]
    )

    page.wait_for_timeout(2000)

    if data["expected"] == "Pass":

        assert "dashboard" in page.url.lower()

    else:

        required_msg = page.locator("//span[text()='Required']")
        invalid_msg = page.locator(".oxd-alert-content-text")

        if required_msg.count() > 0:
            assert required_msg.first.is_visible()
        else:
            assert invalid_msg.is_visible()