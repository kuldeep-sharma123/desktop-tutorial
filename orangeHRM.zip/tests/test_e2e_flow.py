from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from pages.recruitment_page import RecruitmentPage

from utils.csv_reader import read_csv


candidate_data = read_csv(
    "data/candidate_data.csv"
)


def test_add_candidate(page):

    login = LoginPage(page)
    dashboard = DashboardPage(page)
    recruitment = RecruitmentPage(page)

    login.login(
        "Admin",
        "admin123"
    )

    dashboard.goto_recruitment()

    for data in candidate_data:

        recruitment.add_candidate(
            data["first_name"],
            data["middle_name"],
            data["last_name"],
            data["email"],
            data["mobile"],
            data["vacancy"],
            data["resume"]
        )

    page.wait_for_timeout(3000)

    assert "recruitment" in page.url.lower()
