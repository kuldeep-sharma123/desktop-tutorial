from playwright.sync_api import Page


class LoginPage:

    def __init__(self, page: Page):
        self.page = page

        self.username_txt = "input[name='username']"
        self.password_txt = "input[name='password']"
        self.login_btn = "button[type='submit']"
        self.error_msg = ".oxd-alert-content-text"

    def login(self, username, password):
        self.page.fill(self.username_txt, username)
        self.page.fill(self.password_txt, password)
        self.page.click(self.login_btn)

    def get_error_message(self):
        return self.page.locator(self.error_msg).text_content()

    def is_error_displayed(self):
        return self.page.locator(self.error_msg).is_visible()