from playwright.sync_api import Page


class DashboardPage:

    def __init__(self, page: Page):
        self.page = page

        self.admin_menu = "//span[text()='Admin']"
        self.recruitment_menu = "//span[text()='Recruitment']"
        self.dashboard_menu = "//span[text()='Dashboard']"

        self.user_dropdown = ".oxd-userdropdown-tab"
        self.logout_link = "//a[text()='Logout']"

    def goto_admin(self):
        self.page.click(self.admin_menu)

    def goto_recruitment(self):
        self.page.click(self.recruitment_menu)

    def goto_dashboard(self):
        self.page.click(self.dashboard_menu)

    def logout(self):
        self.page.click(self.user_dropdown)
        self.page.click(self.logout_link)