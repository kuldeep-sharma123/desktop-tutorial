from playwright.sync_api import Page


class AdminPage:

    def __init__(self, page: Page):
        self.page = page

        self.add_btn = "//button[normalize-space()='Add']"

        self.user_role_dropdown = "(//div[contains(@class,'oxd-select-text')])[1]"
        self.status_dropdown = "(//div[contains(@class,'oxd-select-text')])[2]"

        self.employee_name = "//input[@placeholder='Type for hints...']"

        self.username = "(//input[contains(@class,'oxd-input')])[3]"

        self.password = "(//input[@type='password'])[1]"
        self.confirm_password = "(//input[@type='password'])[2]"

        self.save_btn = "//button[@type='submit']"

    def add_user(self,
                 employee_name,
                 username,
                 password):

        self.page.click(self.add_btn)

        # User Role
        self.page.click(self.user_role_dropdown)
        self.page.click("//span[text()='ESS']")

        # Employee Name
        self.page.fill(self.employee_name, employee_name)

        self.page.wait_for_timeout(2000)

        self.page.keyboard.press("ArrowDown")
        self.page.keyboard.press("Enter")

        # Status
        self.page.click(self.status_dropdown)
        self.page.click("//span[text()='Enabled']")

        # Credentials
        self.page.locator(self.username).fill(username)
        self.page.locator(self.password).fill(password)
        self.page.locator(self.confirm_password).fill(password)

        self.page.click(self.save_btn)