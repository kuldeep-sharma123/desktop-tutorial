from playwright.sync_api import Page


class RecruitmentPage:

    def __init__(self, page: Page):
        self.page = page

        self.add_btn = "//button[normalize-space()='Add']"

        self.first_name = "input[name='firstName']"
        self.middle_name = "input[name='middleName']"
        self.last_name = "input[name='lastName']"

        self.vacancy_dropdown = "//label[text()='Vacancy']/following::div[contains(@class,'oxd-select-text')][1]"
        self.resume_upload = "input[type='file']"

        self.email = "(//input[@class='oxd-input oxd-input--active'])[3]"
        self.mobile = "(//input[@class='oxd-input oxd-input--active'])[4]"

        self.save_btn = "//button[@type='submit']"

    def add_candidate(
            self,
            first_name,
            middle_name,
            last_name,
            email,
            mobile,
            vacancy,
            resume_Path
    ):
        self.page.click(self.add_btn)

        self.page.fill(self.first_name, first_name)
        self.page.fill(self.middle_name, middle_name)
        self.page.fill(self.last_name, last_name)

        # Vacancy dropdown
        self.page.locator(self.vacancy_dropdown).click()
        self.page.locator(f"//div[@class='orangehrm-file-input']").click()

        self.page.locator(self.email).fill(email)
        self.page.locator(self.mobile).fill(mobile)

        self.page.locator("input[type='file']").set_input_files(resume_Path)

        self.page.click(self.save_btn)