# Corrected OrangeHRM Playwright Flow

Run:

    pip install -r requirements.txt
    playwright install
    pytest tests/test_e2e_flow.py -v -s

Flow:
1. Login as Admin
2. Perform Dashboard task
3. Open Recruitment
4. Add one candidate and upload `data/resume.pdf`
5. Open Admin
6. Add User001 and User002
7. Logout Admin
8. Login User001 -> Dashboard task -> Logout
9. Login User002 -> Dashboard task -> Logout

Before running repeatedly, make sure User001/User002 do not already exist in the demo environment.
Also verify that `Paul Collings` is an existing employee in the OrangeHRM demo account.
