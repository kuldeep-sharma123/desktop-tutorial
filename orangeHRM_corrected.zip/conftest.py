import pytest
from pathlib import Path
from datetime import datetime
from playwright.sync_api import sync_playwright


BASE_URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"


@pytest.fixture(scope="function")
def page():
    playwright = sync_playwright().start()

    browser = playwright.chromium.launch(
        headless=False,
        slow_mo=250,
    )

    page = browser.new_page(
        viewport={"width": 1440, "height": 900}
    )

    page.goto(BASE_URL, wait_until="domcontentloaded")

    yield page

    browser.close()
    playwright.stop()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()

    if report.when == "call" and report.failed:
        page = item.funcargs.get("page")
        if page:
            Path("screenshots").mkdir(exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            page.screenshot(
                path=f"screenshots/{item.name}_{timestamp}.png",
                full_page=True,
            )
