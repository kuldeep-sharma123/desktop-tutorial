import csv


def read_csv(file_path):
    with open(file_path, newline="", encoding="utf-8-sig") as file:
        return list(csv.DictReader(file))
