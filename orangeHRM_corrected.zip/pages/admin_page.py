from playwright.sync_api import Page, expect


class AdminPage:
    def __init__(self, page: Page):
        self.page = page
        self.add_btn = page.get_by_role("button", name="Add")
        self.user_role_dropdown = page.locator(
            "(//div[contains(@class,'oxd-select-text')])[1]"
        )
        self.status_dropdown = page.locator(
            "(//div[contains(@class,'oxd-select-text')])[2]"
        )
        self.employee_name = page.locator("input[placeholder='Type for hints...']")
        self.username = page.locator("//label[text()='Username']/following::input[1]")
        self.password = page.locator("//label[text()='Password']/following::input[1]")
        self.confirm_password = page.locator(
            "//label[text()='Confirm Password']/following::input[1]"
        )
        self.save_btn = page.get_by_role("button", name="Save")

    def add_user(self, employee_name, username, password):
        self.add_btn.click()

        self.user_role_dropdown.click()
        self.page.get_by_text("ESS", exact=True).click()

        self.employee_name.fill(employee_name)
        self.page.wait_for_timeout(1000)

        suggestion = self.page.locator(
            "//div[contains(@class,'oxd-autocomplete-option')]"
        ).first
        expect(suggestion).to_be_visible()
        suggestion.click()

        self.status_dropdown.click()
        self.page.get_by_text("Enabled", exact=True).click()

        self.username.fill(username)
        self.password.fill(password)
        self.confirm_password.fill(password)

        self.save_btn.click()
        self.page.wait_for_timeout(1200)
        expect(self.page).to_have_url(lambda url: "admin" in url.lower())
