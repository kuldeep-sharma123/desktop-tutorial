from playwright.sync_api import Page


class LoginPage:
    def __init__(self, page: Page):
        self.page = page
        self.username_txt = page.locator("input[name='username']")
        self.password_txt = page.locator("input[name='password']")
        self.login_btn = page.get_by_role("button", name="Login")
        self.error_msg = page.locator(".oxd-alert-content-text")

    def login(self, username, password):
        self.username_txt.fill(username)
        self.password_txt.fill(password)
        self.login_btn.click()
        self.page.wait_for_url("**/web/index.php/**", wait_until="domcontentloaded")

    def is_logged_in(self):
        return "dashboard" in self.page.url.lower()

    def is_error_displayed(self):
        return self.error_msg.is_visible()
