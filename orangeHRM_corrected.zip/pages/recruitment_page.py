from playwright.sync_api import Page, expect


class RecruitmentPage:
    def __init__(self, page: Page):
        self.page = page
        self.add_btn = page.get_by_role("button", name="Add")
        self.first_name = page.locator("input[name='firstName']")
        self.middle_name = page.locator("input[name='middleName']")
        self.last_name = page.locator("input[name='lastName']")
        self.vacancy_dropdown = page.locator(
            "//label[text()='Vacancy']/following::div[contains(@class,'oxd-select-text')][1]"
        )
        self.email = page.locator("//label[text()='Email']/following::input[1]")
        self.mobile = page.locator("//label[text()='Contact Number']/following::input[1]")
        self.resume_upload = page.locator("input[type='file']")
        self.save_btn = page.get_by_role("button", name="Save")

    def add_candidate(self, first_name, middle_name, last_name,
                      email, mobile, vacancy, resume_path):
        self.add_btn.click()
        self.first_name.fill(first_name)
        self.middle_name.fill(middle_name)
        self.last_name.fill(last_name)

        self.vacancy_dropdown.click()
        self.page.get_by_text(vacancy, exact=True).click()

        self.email.fill(email)
        self.mobile.fill(mobile)
        self.resume_upload.set_input_files(resume_path)

        self.save_btn.click()
        self.page.wait_for_timeout(1200)
        expect(self.page).to_have_url(lambda url: "recruitment" in url.lower())
