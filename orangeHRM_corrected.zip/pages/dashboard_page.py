from playwright.sync_api import Page, expect


class DashboardPage:
    def __init__(self, page: Page):
        self.page = page
        self.dashboard_menu = page.get_by_text("Dashboard", exact=True).first
        self.admin_menu = page.get_by_text("Admin", exact=True).first
        self.recruitment_menu = page.get_by_text("Recruitment", exact=True).first
        self.user_dropdown = page.locator(".oxd-userdropdown-tab")
        self.logout_link = page.get_by_text("Logout", exact=True)

    def goto_dashboard(self):
        self.dashboard_menu.click()
        self.page.wait_for_timeout(700)
        expect(self.page).to_have_url(lambda url: "dashboard" in url.lower())

    def goto_admin(self):
        self.admin_menu.click()
        self.page.wait_for_timeout(700)
        expect(self.page).to_have_url(lambda url: "admin" in url.lower())

    def goto_recruitment(self):
        self.recruitment_menu.click()
        self.page.wait_for_timeout(700)
        expect(self.page).to_have_url(lambda url: "recruitment" in url.lower())

    def perform_dashboard_task(self):
        expect(self.page).to_have_url(lambda url: "dashboard" in url.lower())
        expect(self.page.get_by_text("Dashboard", exact=True).first).to_be_visible()
        self.page.mouse.wheel(0, 700)
        self.page.wait_for_timeout(400)
        self.page.mouse.wheel(0, -700)

    def logout(self):
        self.user_dropdown.click()
        self.logout_link.click()
        self.page.wait_for_url("**/auth/login", wait_until="domcontentloaded")
