from pathlib import Path

from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from pages.recruitment_page import RecruitmentPage
from pages.admin_page import AdminPage
from utils.csv_reader import read_csv


def test_complete_orangehrm_flow(page):
    login = LoginPage(page)
    dashboard = DashboardPage(page)
    recruitment = RecruitmentPage(page)
    admin = AdminPage(page)

    candidate_data = read_csv("data/candidate_data.csv")
    user_data = read_csv("data/user_data.csv")

    assert len(user_data) >= 2, "user_data.csv must contain at least two users"
    assert len(candidate_data) >= 1, "candidate_data.csv must contain a candidate"

    # 1. Admin login
    login.login("Admin", "admin123")
    assert login.is_logged_in(), "Admin login failed"

    # 2. Admin dashboard task
    dashboard.goto_dashboard()
    dashboard.perform_dashboard_task()

    # 3. Recruitment -> add one candidate
    dashboard.goto_recruitment()
    candidate = candidate_data[0]

    resume_path = Path(candidate["resume"]).resolve()
    assert resume_path.exists(), f"Resume not found: {resume_path}"

    recruitment.add_candidate(
        first_name=candidate["first_name"],
        middle_name=candidate["middle_name"],
        last_name=candidate["last_name"],
        email=candidate["email"],
        mobile=candidate["mobile"],
        vacancy=candidate["vacancy"],
        resume_path=str(resume_path),
    )

    # 4. Recruitment -> Admin
    dashboard.goto_admin()

    # 5. Add exactly two users
    for user in user_data[:2]:
        admin.add_user(
            employee_name=user["employee_name"],
            username=user["username"],
            password=user["password"],
        )

    # 6. Logout Admin
    dashboard.logout()

    # 7. User 1 login -> dashboard task -> logout
    for user in user_data[:2]:
        login.login(user["username"], user["password"])
        assert login.is_logged_in(), f"Login failed for {user['username']}"

        dashboard.goto_dashboard()
        dashboard.perform_dashboard_task()
        dashboard.logout()
